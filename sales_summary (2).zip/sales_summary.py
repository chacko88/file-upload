# Read the sales log and calculate total spent by each customer
def process_sales_log(input_file_path, output_file_path):
    sales_data = {}

    # Read the input file
    with open(input_file_path, 'r') as input_file:
        for record in input_file:
            # Split the line into customer, item, and amount
            buyer, product, price = record.strip().split(',')
            price = float(price)  # Convert price to float

            # Accumulate the total for each customer
            if buyer in sales_data:
                sales_data[buyer] += price
            else:
                sales_data[buyer] = price

    # Sort customers by total spent in descending order
    sorted_sales = sorted(sales_data.items(), key=lambda x: x[1], reverse=True)

    # Write the summary to the output file
    with open(output_file_path, 'w') as output_file:
        for buyer, total_spent in sorted_sales:
            output_file.write(f"Customer: {buyer} | Total Spent: €{round(total_spent, 2)}\n")

# Define input and output file names
input_file_path = 'sales_log.txt'
output_file_path = 'sales_summary.txt'

# Process the sales log and generate the summary
process_sales_log(input_file_path, output_file_path)

print(f"Sales summary has been written to {output_file_path}")