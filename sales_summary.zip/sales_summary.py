# Read the sales log and calculate total spent by each customer
def process_sales_log(input_file, output_file):
    customer_totals = {}

    # Read the input file
    with open(input_file, 'r') as file:
        for line in file:
            # Split the line into customer, item, and amount
            customer, item, amount = line.strip().split(',')
            amount = float(amount)  # Convert amount to float

            # Accumulate the total for each customer
            if customer in customer_totals:
                customer_totals[customer] += amount
            else:
                customer_totals[customer] = amount

    # Write the summary to the output file
    with open(output_file, 'w') as file:
        for customer, total in customer_totals.items():
            file.write(f"Customer: {customer} | Total Spent: €{round(total, 2)}\n")

# Define input and output file names
input_file = 'sales_log.txt'
output_file = 'sales_summary.txt'

# Process the sales log and generate the summary
process_sales_log(input_file, output_file)

print(f"Sales summary has been written to {output_file}")