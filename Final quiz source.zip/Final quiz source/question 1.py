import pandas as pd

# Load the Excel file and specify the sheet name
file_path = "sagatave_eksamenam.xlsx"
sheet_name = "Lapa_0"

# Read the data starting from row 3
data = pd.read_excel(file_path, sheet_name=sheet_name, header=2)

# Filter records where 'Adrese' starts with "Ain" and 'Skaits' is less than 40
filtered_data = data[(data['Adrese'].str.startswith("Ain")) & (data['Skaits'] < 40)]

# Calculate the number of records
record_count = len(filtered_data)

print(f"Number of records: {record_count}")
