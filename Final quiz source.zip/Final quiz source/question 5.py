import pandas as pd
import math

# Load the Excel file and specify the sheet name
file_path = "sagatave_eksamenam.xlsx"
sheet_name = "Lapa_0"

# Read the sheet into a DataFrame, considering headers in row 3 (index 2)
df = pd.read_excel(file_path, sheet_name=sheet_name, header=2)

# Filter rows where 'Klients' is "Korporatīvais" and 'Skaits' is in the range 40–50
filtered_df = df[(df['Klients'] == "Korporatīvais") & (df['Skaits'].between(40, 50))]

# Calculate the total sum of the 'Kopā' column for the filtered rows
total_sum = filtered_df['Kopā'].sum()

# Round down the total sum to an integer
total_sum_rounded = math.floor(total_sum)

# Print the result
print(f"The total sum is: {total_sum_rounded}")
