import pandas as pd
import math

# Load the Excel file and specify the sheet name
file_path = "sagatave_eksamenam.xlsx"
sheet_name = "Lapa_0"

# Read the sheet into a DataFrame, considering headers in row 3 (index 2)
df = pd.read_excel(file_path, sheet_name=sheet_name, header=2)

# Filter rows where 'Produkts' contains "LaserJet"
laserjet_products = df[df['Produkts'].str.contains("LaserJet", na=False)]

# Calculate the average of the 'Cena' column for the filtered rows
average_cena = laserjet_products['Cena'].mean()

# Round down the average to an integer
average_cena_rounded = math.floor(average_cena)

# Print the result
print(f"The average total is: {average_cena_rounded}")
