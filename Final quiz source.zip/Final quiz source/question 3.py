import pandas as pd

# Load the Excel file and specify the sheet name
file_path = "sagatave_eksamenam.xlsx"
sheet_name = "Lapa_0"

# Read the sheet into a DataFrame, considering headers in row 3 (index 2)
df = pd.read_excel(file_path, sheet_name=sheet_name, header=2)

# Filter rows where 'Adrese' is "Adulienas iela" and 'Pilsēta' is either "Valmiera" or "Saulkrasti"
filtered_df = df[(df['Adrese'] == "Adulienas iela") & (df['Pilsēta'].isin(["Valmiera", "Saulkrasti"]))]

# Count the number of matching rows
count = len(filtered_df)

# Print the result
print(f"The count is: {count}")
