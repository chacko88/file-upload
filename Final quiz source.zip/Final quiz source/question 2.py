import pandas as pd

# Load the Excel file and specify the sheet name
file_path = 'sagatave_eksamenam.xlsx'
sheet_name = 'Lapa_0'

# Read the data from the specified sheet, setting row 3 as the header
data = pd.read_excel(file_path, sheet_name=sheet_name, header=2)

# Filter rows where 'Prioritāte' is 'High' and 'Piegādes datums' is in the year 2015
filtered_data = data[
    (data['Prioritāte'] == 'High') &
    (pd.to_datetime(data['Piegādes datums']).dt.year == 2015)
]

# Calculate the number of entries
entry_count = len(filtered_data)

# Print the result
print(f"Number of entries with 'High' priority and delivery date in 2015: {entry_count}")
